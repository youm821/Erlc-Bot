const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, 'data.json');

function load() {
  if (!fs.existsSync(DATA_FILE)) return {};
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch {
    return {};
  }
}

function save(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function guildData(data, guildId) {
  if (!data[guildId]) data[guildId] = {};
  return data[guildId];
}

function nextId() {
  // Short, human-typeable id - unique enough for a moderation log, not a UUID.
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

/**
 * Per-guild data shape:
 * {
 *   [guildId]: {
 *     channelId, messageId,              // live status embed binding (unchanged, top-level for backward compat)
 *     infractionLogChannelId,
 *     promotionLogChannelId,
 *     infractions: { [userId]: [ { id, type, reason, issuedBy, issuedByTag, timestamp } ] },
 *     promotions:  { [userId]: [ { id, from, to, reason, issuedBy, issuedByTag, timestamp } ] },
 *   }
 * }
 */
const Storage = {
  // ---- Live status embed binding (existing) ----
  getBinding(guildId) {
    const data = load();
    const g = data[guildId];
    if (!g || !g.channelId) return null;
    return { channelId: g.channelId, messageId: g.messageId };
  },

  setBinding(guildId, channelId, messageId) {
    const data = load();
    const g = guildData(data, guildId);
    g.channelId = channelId;
    g.messageId = messageId;
    save(data);
  },

  clearBinding(guildId) {
    const data = load();
    const g = data[guildId];
    if (g) {
      delete g.channelId;
      delete g.messageId;
    }
    save(data);
  },

  allBindings() {
    const data = load();
    const out = {};
    for (const [guildId, g] of Object.entries(data)) {
      if (g && g.channelId) out[guildId] = { channelId: g.channelId, messageId: g.messageId };
    }
    return out;
  },

  // ---- Infraction / promotion log channels ----
  setLogChannel(guildId, kind, channelId) {
    const data = load();
    const g = guildData(data, guildId);
    g[`${kind}LogChannelId`] = channelId;
    save(data);
  },

  getLogChannel(guildId, kind) {
    const data = load();
    return data[guildId]?.[`${kind}LogChannelId`] ?? null;
  },

  // ---- Infraction / promotion records ----
  addRecord(guildId, kind, userId, record) {
    const data = load();
    const g = guildData(data, guildId);
    if (!g[kind]) g[kind] = {};
    if (!g[kind][userId]) g[kind][userId] = [];
    const full = { id: nextId(), timestamp: Math.floor(Date.now() / 1000), ...record };
    g[kind][userId].push(full);
    save(data);
    return full;
  },

  getRecords(guildId, kind, userId) {
    const data = load();
    return data[guildId]?.[kind]?.[userId] ?? [];
  },

  // ---- 24/7 voice channel binding ----
  setVoiceChannel(guildId, channelId) {
    const data = load();
    const g = guildData(data, guildId);
    g.voiceChannelId = channelId;
    save(data);
  },

  clearVoiceChannel(guildId) {
    const data = load();
    const g = data[guildId];
    if (g) delete g.voiceChannelId;
    save(data);
  },

  getVoiceChannel(guildId) {
    const data = load();
    return data[guildId]?.voiceChannelId ?? null;
  },

  /** { [guildId]: channelId } for every guild with a saved voice binding. */
  allVoiceChannels() {
    const data = load();
    const out = {};
    for (const [guildId, g] of Object.entries(data)) {
      if (g && g.voiceChannelId) out[guildId] = g.voiceChannelId;
    }
    return out;
  },
};

module.exports = { Storage };
