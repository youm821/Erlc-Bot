const { SlashCommandBuilder, ChannelType, EmbedBuilder, AttachmentBuilder, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { suggestionTemplateExists, buildFromSuggestionTemplate } = require('./templateEngine');

const DATA_FILE = path.join(__dirname, 'suggestions-data.json');
const UP = '👍';
const DOWN = '👎';

function load() {
  if (!fs.existsSync(DATA_FILE)) return { config: {}, counter: 0, tracked: {} };
  try {
    const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    if (!data.tracked) data.tracked = {};
    return data;
  } catch {
    return { config: {}, counter: 0, tracked: {} };
  }
}

function save(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function getChannel(guildId) {
  const data = load();
  return data.config[guildId]?.channelId ?? null;
}

function setChannel(guildId, channelId) {
  const data = load();
  data.config[guildId] = { channelId };
  save(data);
}

function nextNumber() {
  const data = load();
  data.counter = (data.counter ?? 0) + 1;
  save(data);
  return data.counter;
}

/** Remembers the info needed to rebuild a suggestion's payload later (when vote counts change). */
function trackSuggestion(messageId, info) {
  const data = load();
  data.tracked[messageId] = info;
  save(data);
}

function getTrackedSuggestion(messageId) {
  const data = load();
  return data.tracked[messageId] ?? null;
}

/** Builds the message payload for a suggestion - custom suggestionTemplate.json if present, else a clean built-in embed. */
function buildSuggestionPayload(data) {
  if (suggestionTemplateExists()) {
    try {
      const result = buildFromSuggestionTemplate(data);
      const files = result.attachmentFilenames
        .map((name) => {
          const filePath = path.join(__dirname, 'assets', name);
          return fs.existsSync(filePath) ? new AttachmentBuilder(filePath, { name }) : null;
        })
        .filter(Boolean);

      if (result.mode === 'components_v2') {
        return { payload: { components: result.components, flags: MessageFlags.IsComponentsV2 }, files };
      }
      return { payload: { embeds: result.embeds }, files };
    } catch (err) {
      console.error('[suggestions] Failed to load suggestionTemplate.json, falling back to built-in design:', err.message);
    }
  }

  const embed = new EmbedBuilder()
    .setAuthor({ name: data.author_tag, iconURL: data.author_icon })
    .setTitle(`Suggestion #${data.number}`)
    .setDescription(data.suggestion)
    .setColor(0x5865f2)
    .setFooter({ text: `👍 ${data.upvotes ?? 0}   👎 ${data.downvotes ?? 0}` })
    .setTimestamp();
  return { payload: { embeds: [embed] }, files: [] };
}

/**
 * Recomputes the live vote counts from a message's actual reactions and
 * edits the message in place. Called whenever a reaction is added/removed
 * on a tracked suggestion message.
 */
async function refreshVoteCounts(message) {
  const tracked = getTrackedSuggestion(message.id);
  if (!tracked) return;

  // Subtract 1 from each - that's the bot's own initial reaction, not a real vote.
  const upReaction = message.reactions.cache.get(UP);
  const downReaction = message.reactions.cache.get(DOWN);
  const upvotes = Math.max(0, (upReaction?.count ?? 0) - 1);
  const downvotes = Math.max(0, (downReaction?.count ?? 0) - 1);

  const data = { ...tracked, upvotes, downvotes };
  const { payload } = buildSuggestionPayload(data);

  try {
    await message.edit(payload);
  } catch (err) {
    console.error('[suggestions] Failed to update vote counts on message:', err.message);
  }
}

/**
 * Wires up the suggestion system. Call once after the client is created:
 *   suggestions.attach(client, { authorizedIds: AUTHORIZED_IDS });
 */
function attach(client, { authorizedIds } = {}) {
  // ---- Slash commands ----
  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (!['suggest', 'setsuggestionchannel'].includes(interaction.commandName)) return;

    try {
      if (interaction.commandName === 'setsuggestionchannel') {
        if (!authorizedIds?.has(interaction.user.id)) {
          await interaction.reply({ content: "You're not authorized to configure this.", flags: MessageFlags.Ephemeral });
          return;
        }
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const channel = interaction.options.getChannel('channel', true);
        setChannel(interaction.guildId, channel.id);
        await interaction.editReply(`✅ Suggestions will now be posted in <#${channel.id}>.`);
        return;
      }

      if (interaction.commandName === 'suggest') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const channelId = getChannel(interaction.guildId);
        if (!channelId) {
          await interaction.editReply("⚠️ Suggestions aren't set up in this server yet. Ask an admin to run /setsuggestionchannel.");
          return;
        }
        const channel = await client.channels.fetch(channelId).catch(() => null);
        if (!channel) {
          await interaction.editReply('⚠️ Configured suggestions channel is missing. Ask an admin to reconfigure it.');
          return;
        }

        const text = interaction.options.getString('suggestion', true);
        const number = nextNumber();
        const timestamp = Math.floor(Date.now() / 1000);

        const data = {
          author_tag: interaction.user.tag,
          author_mention: `<@${interaction.user.id}>`,
          author_id: interaction.user.id,
          author_icon: interaction.user.displayAvatarURL(),
          suggestion: text,
          number,
          date: `<t:${timestamp}:F>`,
          date_relative: `<t:${timestamp}:R>`,
          upvotes: 0,
          downvotes: 0,
        };

        const { payload, files } = buildSuggestionPayload(data);
        const posted = await channel.send({ ...payload, files });
        await posted.react(UP).catch(() => {});
        await posted.react(DOWN).catch(() => {});

        // Save everything needed to rebuild this exact payload later, minus the live vote counts (recomputed each time).
        const { upvotes, downvotes, ...persisted } = data;
        trackSuggestion(posted.id, persisted);

        await interaction.editReply(`✅ Your suggestion was posted as **#${number}** in <#${channel.id}>.`);
        return;
      }
    } catch (err) {
      console.error(`[suggestions] Error handling /${interaction.commandName}:`, err.message);
      const msg = '⚠️ Something went wrong with that command.';
      try {
        if (interaction.deferred || interaction.replied) await interaction.editReply(msg);
        else await interaction.reply({ content: msg, flags: MessageFlags.Ephemeral });
      } catch {
        // interaction token expired - nothing more we can do
      }
    }
  });

  // ---- Live vote count updates ----
  const onReactionChange = async (reaction, user) => {
    if (user.bot) return; // ignore the bot's own initial reactions
    if (![UP, DOWN].includes(reaction.emoji.name)) return;

    try {
      if (reaction.partial) await reaction.fetch();
      if (reaction.message.partial) await reaction.message.fetch();
    } catch (err) {
      console.error('[suggestions] Failed to fetch partial reaction/message:', err.message);
      return;
    }

    await refreshVoteCounts(reaction.message);
  };

  client.on('messageReactionAdd', onReactionChange);
  client.on('messageReactionRemove', onReactionChange);
}

const commands = [
  new SlashCommandBuilder()
    .setName('suggest')
    .setDescription('Submit a suggestion for staff to review.')
    .addStringOption((o) => o.setName('suggestion').setDescription('Your suggestion.').setRequired(true)),

  new SlashCommandBuilder()
    .setName('setsuggestionchannel')
    .setDescription('Set which channel suggestions get posted to. (Staff only)')
    .addChannelOption((o) =>
      o.setName('channel').setDescription('Channel for suggestions.').addChannelTypes(ChannelType.GuildText).setRequired(true)
    ),
];

module.exports = { attach, commands };
