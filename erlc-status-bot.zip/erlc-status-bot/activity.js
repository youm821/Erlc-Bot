const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, 'activity-data.json');
const RETENTION_DAYS = 30;
const WEEK_MS = 7 * 24 * 60 * 60 * 1000;

function load() {
  if (!fs.existsSync(DATA_FILE)) return { quota: 5, log: {} };
  try {
    const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    if (typeof data.quota !== 'number') data.quota = 5;
    if (!data.log) data.log = {};
    return data;
  } catch {
    return { quota: 5, log: {} };
  }
}

function save(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function logActivity(userId, userTag) {
  const data = load();
  const cutoff = Date.now() - RETENTION_DAYS * 24 * 60 * 60 * 1000;
  if (!data.log[userId]) data.log[userId] = { tag: userTag, timestamps: [] };
  data.log[userId].tag = userTag; // keep tag fresh in case it changed
  data.log[userId].timestamps.push(Date.now());
  data.log[userId].timestamps = data.log[userId].timestamps.filter((ts) => ts > cutoff);
  save(data);
}

function getWeeklyCounts() {
  const data = load();
  const cutoff = Date.now() - WEEK_MS;
  const counts = [];
  for (const [userId, entry] of Object.entries(data.log)) {
    const count = entry.timestamps.filter((ts) => ts > cutoff).length;
    counts.push({ userId, tag: entry.tag, count });
  }
  return counts.sort((a, b) => b.count - a.count);
}

function setQuota(count) {
  const data = load();
  data.quota = count;
  save(data);
}

function getQuota() {
  return load().quota;
}

/**
 * Wires up staff activity tracking. Call once after the client is created:
 *   activity.attach(client, { authorizedIds: AUTHORIZED_IDS });
 *
 * Logs one entry every time an authorized user successfully runs ANY slash
 * command (not just this module's own) - so it needs to see every
 * interaction, unlike the other self-contained modules.
 */
function attach(client, { authorizedIds } = {}) {
  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    // Passive logging for every command run by a tracked staff member.
    if (authorizedIds?.has(interaction.user.id) && !['activity', 'setactivityquota'].includes(interaction.commandName)) {
      logActivity(interaction.user.id, interaction.user.tag);
    }

    if (!['activity', 'setactivityquota'].includes(interaction.commandName)) return;

    try {
      if (!authorizedIds?.has(interaction.user.id)) {
        await interaction.reply({ content: "You're not authorized to use this.", flags: MessageFlags.Ephemeral });
        return;
      }

      if (interaction.commandName === 'setactivityquota') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const count = interaction.options.getInteger('count', true);
        setQuota(count);
        await interaction.editReply(`✅ Weekly command quota set to **${count}**.`);
        return;
      }

      if (interaction.commandName === 'activity') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const quota = getQuota();
        const counts = getWeeklyCounts();
        if (!counts.length) {
          await interaction.editReply('No activity logged yet.');
          return;
        }
        const lines = counts.map((c) => {
          const flag = c.count < quota ? ' ⚠️ below quota' : '';
          return `**${c.tag}**: ${c.count} commands this week${flag}`;
        });
        await interaction.editReply(`**Staff activity (weekly quota: ${quota}):**\n${lines.join('\n')}`);
        return;
      }
    } catch (err) {
      console.error(`[activity] Error handling /${interaction.commandName}:`, err.message);
      const msg = '⚠️ Something went wrong with that command.';
      try {
        if (interaction.deferred || interaction.replied) await interaction.editReply(msg);
        else await interaction.reply({ content: msg, flags: MessageFlags.Ephemeral });
      } catch {
        // interaction token expired - nothing more we can do
      }
    }
  });
}

const commands = [
  new SlashCommandBuilder().setName('activity').setDescription('Show weekly staff command activity vs quota. (Staff only)'),

  new SlashCommandBuilder()
    .setName('setactivityquota')
    .setDescription('Set the minimum weekly command count for staff. (Staff only)')
    .addIntegerOption((o) => o.setName('count').setDescription('Minimum commands per week.').setRequired(true)),
];

module.exports = { attach, commands, logActivity, getWeeklyCounts, getQuota, setQuota };
