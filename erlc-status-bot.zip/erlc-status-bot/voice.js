const {
  joinVoiceChannel,
  VoiceConnectionStatus,
  entersState,
  getVoiceConnection,
} = require('@discordjs/voice');

// One active connection per guild, keyed by guildId, so we never leak/duplicate connections.
const connections = new Map();

/**
 * Joins (or moves to) the given voice channel and keeps the bot there:
 * automatically rejoins on disconnects that aren't a deliberate move (e.g. a
 * Discord voice-server hiccup, someone force-disconnecting the bot, a region
 * change) instead of just silently dropping out of the channel.
 */
async function joinAndHold(client, guildId, channelId) {
  const guild = client.guilds.cache.get(guildId) ?? (await client.guilds.fetch(guildId).catch(() => null));
  if (!guild) {
    console.error(`[voice] Can't join VC: guild ${guildId} not found.`);
    return null;
  }

  // Replace any existing connection for this guild rather than stacking a second one.
  const existing = getVoiceConnection(guildId);
  if (existing) existing.destroy();

  const connection = joinVoiceChannel({
    channelId,
    guildId,
    adapterCreator: guild.voiceAdapterCreator,
    selfDeaf: true,
    selfMute: true,
  });

  connections.set(guildId, connection);

  connection.on(VoiceConnectionStatus.Disconnected, async () => {
    try {
      // A "Disconnected" state can just be Discord momentarily rebuilding the
      // voice websocket (e.g. during a region change) - give it a few seconds
      // to resolve on its own before treating it as a real drop.
      await Promise.race([
        entersState(connection, VoiceConnectionStatus.Signalling, 5_000),
        entersState(connection, VoiceConnectionStatus.Connecting, 5_000),
      ]);
    } catch {
      // Genuine disconnect (kicked from the channel, channel deleted, etc.) - rebuild from scratch.
      connection.destroy();
      connections.delete(guildId);
      console.warn(`[voice] Lost connection in guild ${guildId}, retrying in 10s...`);
      setTimeout(() => joinAndHold(client, guildId, channelId), 10_000);
    }
  });

  connection.on(VoiceConnectionStatus.Destroyed, () => {
    connections.delete(guildId);
  });

  connection.on('error', (err) => {
    console.error(`[voice] Connection error in guild ${guildId}:`, err.message);
  });

  try {
    await entersState(connection, VoiceConnectionStatus.Ready, 20_000);
    console.log(`[voice] Joined voice channel ${channelId} in guild ${guildId}.`);
  } catch (err) {
    console.error('[voice] Failed to connect within 20s:', err.message);
  }

  return connection;
}

/** Disconnects and forgets the voice connection for a guild, if any. Returns whether one existed. */
function leave(guildId) {
  const connection = getVoiceConnection(guildId) ?? connections.get(guildId);
  if (connection) {
    connection.destroy();
    connections.delete(guildId);
    return true;
  }
  return false;
}

module.exports = { joinAndHold, leave };
