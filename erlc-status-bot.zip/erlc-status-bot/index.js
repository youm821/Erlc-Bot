require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, MessageFlags, AttachmentBuilder, Partials } = require('discord.js');
const { updatePresence } = require('./presence');
const { ERLCApi } = require('./erlcApi');
const { buildStatusEmbeds, buildInfractionEmbed, buildPromotionEmbed } = require('./embedBuilder');
const {
  templateExists,
  buildFromTemplate,
  infractionTemplateExists,
  buildFromInfractionTemplate,
  promotionTemplateExists,
  buildFromPromotionTemplate,
} = require('./templateEngine');
const { Storage } = require('./storage');
const { joinAndHold, leave: leaveVoice } = require('./voice');
const modmail = require('./modmail');
const suggestions = require('./suggestions');
const sessionReminders = require('./sessionReminders');
const activity = require('./activity');

// Banner images attached once when the embed is first posted. Discord keeps them
// on the message afterwards, so refreshes only need to re-send the embeds, not the files.
const bannerAttachments = [
  new AttachmentBuilder(path.join(__dirname, 'assets', 'banner_top.png'), { name: 'banner_top.png' }),
  new AttachmentBuilder(path.join(__dirname, 'assets', 'banner_bottom.png'), { name: 'banner_bottom.png' }),
];

const REFRESH_SECONDS = Math.max(15, parseInt(process.env.REFRESH_SECONDS || '60', 10));

// Everyone allowed to run commands. Supports a single OWNER_ID plus a
// comma-separated OWNER_IDS list, e.g. OWNER_IDS=123456789,987654321
const AUTHORIZED_IDS = new Set(
  [process.env.OWNER_ID, ...(process.env.OWNER_IDS || '').split(',')]
    .map((id) => id && id.trim())
    .filter(Boolean)
);

// Commands regular members are allowed to run even if they're not in
// AUTHORIZED_IDS - mod mail needs to be usable by anyone, not just staff.
const BYPASS_OWNER_GATE = new Set(['modmail', 'close', 'suggest']);

// Discord message content has a 2000 character limit; leave headroom for the header line.
const LIST_CHAR_LIMIT = 1900;

/** Splits a "PlayerName:RobloxId" string into its two parts, tolerating missing ids. */
function splitPlayerString(entry) {
  if (typeof entry !== 'string') return { name: String(entry), id: null };
  const idx = entry.lastIndexOf(':');
  return idx === -1 ? { name: entry, id: null } : { name: entry.slice(0, idx), id: entry.slice(idx + 1) };
}

/** Turns an array/object of items into a newline list, truncated to fit one Discord message. */
function formatList(lines, emptyMessage) {
  if (!lines.length) return emptyMessage;
  let out = '';
  for (const line of lines) {
    if (out.length + line.length + 1 > LIST_CHAR_LIMIT) {
      out += `\n…and ${lines.length - lines.indexOf(line)} more`;
      break;
    }
    out += (out ? '\n' : '') + line;
  }
  return out;
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
  ],
  // Reaction/message events can arrive "partial" (uncached, e.g. after a
  // restart) - these let discord.js fetch the full data instead of ignoring them.
  partials: [Partials.Message, Partials.Reaction, Partials.Channel],
});
const api = new ERLCApi(process.env.ERLC_SERVER_KEY);

/**
 * Builds the message payload to post/edit, plus which AttachmentBuilder files
 * (if any) need to accompany the *first* send. Prefers a custom template.json
 * (exported from discohook.org) if one exists; otherwise falls back to the
 * built-in banner-top / status-card / banner-bottom design.
 *
 * Returns { payload, files } where `payload` is ready to spread directly into
 * channel.send()/message.edit() (e.g. { components, flags } or { embeds }).
 */
function buildMessagePayload(snapshot) {
  if (templateExists()) {
    try {
      const result = buildFromTemplate(snapshot);
      const files = result.attachmentFilenames
        .map((name) => {
          const filePath = path.join(__dirname, 'assets', name);
          return fs.existsSync(filePath) ? new AttachmentBuilder(filePath, { name }) : null;
        })
        .filter(Boolean);

      if (result.mode === 'components_v2') {
        return {
          payload: { components: result.components, flags: MessageFlags.IsComponentsV2 },
          files,
        };
      }
      return { payload: { embeds: result.embeds }, files };
    } catch (err) {
      console.error('Failed to load template.json, falling back to built-in design:', err.message);
    }
  }

  return {
    payload: { embeds: buildStatusEmbeds(snapshot, { refreshSeconds: REFRESH_SECONDS }) },
    files: bannerAttachments,
  };
}

/**
 * Same idea as buildMessagePayload, but for one-off infraction/promotion
 * notices. `kind` is 'infraction' or 'promotion'. `data` is a flat object
 * with both the snake_case keys a custom template uses ({{target_tag}} etc.)
 * and the same keys the built-in fallback embed expects - see the /infraction
 * and /promotion command handlers for exactly what's included.
 */
function buildNoticePayload(kind, data) {
  const exists = kind === 'infraction' ? infractionTemplateExists() : promotionTemplateExists();

  if (exists) {
    try {
      const builder = kind === 'infraction' ? buildFromInfractionTemplate : buildFromPromotionTemplate;
      const result = builder(data);
      const files = result.attachmentFilenames
        .map((name) => {
          const filePath = path.join(__dirname, 'assets', name);
          return fs.existsSync(filePath) ? new AttachmentBuilder(filePath, { name }) : null;
        })
        .filter(Boolean);

      if (result.mode === 'components_v2') {
        return { payload: { components: result.components, flags: MessageFlags.IsComponentsV2 }, files };
      }
      return { payload: { embeds: result.embeds }, files };
    } catch (err) {
      console.error(`Failed to load ${kind}Template.json, falling back to built-in design:`, err.message);
    }
  }

  const fallback = kind === 'infraction' ? buildInfractionEmbed(data) : buildPromotionEmbed(data);
  return { payload: fallback, files: [] };
}

// ---- Core refresh logic, reused by the timer and by manual commands ----

async function refreshGuild(guildId) {
  const binding = Storage.getBinding(guildId);
  if (!binding) return;

  const channel = await client.channels.fetch(binding.channelId).catch(() => null);
  if (!channel) {
    Storage.clearBinding(guildId);
    return;
  }

  const snapshot = await api.getSnapshot();
  const { payload, files } = buildMessagePayload(snapshot);

  const message = await channel.messages.fetch(binding.messageId).catch(() => null);
  if (!message) {
    // Original message got deleted -> post a fresh one (with any needed files) and rebind.
    const newMessage = await channel.send({ ...payload, files });
    Storage.setBinding(guildId, channel.id, newMessage.id);
    return;
  }

  // Not re-sending `files` here: Discord keeps existing attachments on an edit,
  // and the payload references them by filename via attachment://.
  await message.edit(payload);
}

async function refreshAllGuilds() {
  const bindings = Storage.allBindings();
  for (const guildId of Object.keys(bindings)) {
    try {
      await refreshGuild(guildId);
    } catch (err) {
      console.error(`Failed to refresh status for guild ${guildId}:`, err.message);
    }
  }
}

// ---- Slash command handling ----

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  try {
    const isOwner = AUTHORIZED_IDS.has(interaction.user.id) || BYPASS_OWNER_GATE.has(interaction.commandName);
    if (!isOwner) {
      await interaction.reply({
        content: "You're not authorized to use this bot's commands.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    if (interaction.commandName === 'setstatus') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const snapshot = await api.getSnapshot();
      const { payload, files } = buildMessagePayload(snapshot);
      const message = await interaction.channel.send({ ...payload, files });

      Storage.setBinding(interaction.guildId, interaction.channelId, message.id);

      await interaction.editReply(
        `✅ Live ER:LC status posted here. It will auto-refresh every ${REFRESH_SECONDS}s.`
      );
      return;
    }

    if (interaction.commandName === 'statusrefresh') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const binding = Storage.getBinding(interaction.guildId);
      if (!binding) {
        await interaction.editReply('No status embed is set up yet. Run `/setstatus` first.');
        return;
      }
      await refreshGuild(interaction.guildId);
      await interaction.editReply('🔄 Status refreshed.');
      return;
    }

    if (interaction.commandName === 'statusstop') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const binding = Storage.getBinding(interaction.guildId);
      if (!binding) {
        await interaction.editReply('There is no live status feed running for this server.');
        return;
      }
      Storage.clearBinding(interaction.guildId);
      await interaction.editReply('🛑 Live status feed stopped. The last embed will stay but stop updating.');
      return;
    }

    if (interaction.commandName === 'players') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const players = await api.getPlayers();
      const lines = players.map((p) => {
        const { name } = splitPlayerString(p.Player);
        const team = p.Team ? ` — ${p.Team}` : '';
        const callsign = p.Callsign ? ` (${p.Callsign})` : '';
        return `**${name}**${team}${callsign}`;
      });
      await interaction.editReply(
        `**In-game players (${players.length}):**\n${formatList(lines, 'Nobody is currently in-game.')}`
      );
      return;
    }

    if (interaction.commandName === 'queue') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const queue = await api.getQueue();
      const lines = queue.map((entry, i) => {
        if (entry && typeof entry === 'object') {
          const { name } = splitPlayerString(entry.Player ?? '');
          return `${i + 1}. ${name || 'Unknown'}`;
        }
        return `${i + 1}. Roblox ID \`${entry}\``;
      });
      await interaction.editReply(
        `**In queue (${queue.length}):**\n${formatList(lines, 'The queue is empty.')}`
      );
      return;
    }

    if (interaction.commandName === 'bans') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      let bans;
      try {
        bans = await api.getBans();
      } catch (err) {
        await interaction.editReply(
          "⚠️ The ER:LC ban list endpoint isn't available for this server (bans are now handled through Roblox's own system rather than PRC's API). Check your Roblox account bans page instead."
        );
        return;
      }
      let lines = [];
      if (Array.isArray(bans)) {
        lines = bans.map((entry) => {
          const { name, id } = splitPlayerString(entry);
          return id ? `**${name}** (\`${id}\`)` : `**${name}**`;
        });
      } else if (bans && typeof bans === 'object') {
        lines = Object.entries(bans).map(([id, name]) => `**${name}** (\`${id}\`)`);
      }
      await interaction.editReply(
        `**Banned players (${lines.length}):**\n${formatList(lines, 'No one is currently banned.')}`
      );
      return;
    }

    if (interaction.commandName === 'command') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const commandText = interaction.options.getString('text', true);
      await api.runCommand(commandText);
      await interaction.editReply(`✅ Sent to the server: \`${commandText}\``);
      return;
    }

    if (interaction.commandName === 'presence') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const customText = interaction.options.getString('text') ?? undefined;
      const result = await updatePresence(client, { api, text: customText });
      if (result.ok) {
        await interaction.editReply(
          `✅ Presence set to: **${result.name}**\nCheck the bot's name in your server's member list (not this DM/reply) — it can take a few seconds and a Discord client restart to visibly update.`
        );
      } else {
        await interaction.editReply(`⚠️ Couldn't set presence: ${result.reason}`);
      }
      return;
    }

    if (interaction.commandName === 'staff') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const staff = await api.getStaff();
      const lines = staff.map((s) => `**${s.name}** — ${s.role} (\`${s.id}\`)`);
      await interaction.editReply(
        `**Online staff (${staff.length}):**\n${formatList(lines, 'No staff currently online.')}`
      );
      return;
    }

    if (interaction.commandName === 'vehicles') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const vehicles = await api.getVehicles();
      const lines = vehicles.map((v) => {
        const owner = v.Owner ? splitPlayerString(v.Owner).name : 'Unknown';
        const name = v.Name ?? v.Texture ?? 'Unknown vehicle';
        return `**${name}** — ${owner}`;
      });
      await interaction.editReply(
        `**Spawned vehicles (${vehicles.length}):**\n${formatList(lines, 'No vehicles currently spawned.')}`
      );
      return;
    }

    if (interaction.commandName === 'killlogs') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const logs = await api.getKillLogs();
      const lines = logs
        .slice()
        .reverse()
        .map((entry) => {
          const killer = splitPlayerString(entry.Killer).name;
          const killed = splitPlayerString(entry.Killed).name;
          const ts = `<t:${entry.Timestamp}:R>`;
          return `**${killer}** killed **${killed}** — ${ts}`;
        });
      await interaction.editReply(
        `**Recent kill logs:**\n${formatList(lines, 'No recent kill activity.')}`
      );
      return;
    }

    if (interaction.commandName === 'commandlogs') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const logs = await api.getCommandLogs();
      const lines = logs
        .slice()
        .reverse()
        .map((entry) => {
          const player = splitPlayerString(entry.Player).name;
          const ts = `<t:${entry.Timestamp}:R>`;
          return `**${player}**: \`${entry.Command}\` — ${ts}`;
        });
      await interaction.editReply(
        `**Recent command logs:**\n${formatList(lines, 'No recent command activity.')}`
      );
      return;
    }

    if (interaction.commandName === 'joinlogs') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const logs = await api.getJoinLogs();
      const lines = logs
        .slice()
        .reverse()
        .map((entry) => {
          const player = splitPlayerString(entry.Player).name;
          const action = entry.Join ? 'joined' : 'left';
          const ts = `<t:${entry.Timestamp}:R>`;
          return `**${player}** ${action} — ${ts}`;
        });
      await interaction.editReply(
        `**Recent join/leave activity:**\n${formatList(lines, 'No recent join/leave activity.')}`
      );
      return;
    }

    if (interaction.commandName === 'serverinfo') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const server = await api.getServer();
      if (!server) {
        await interaction.editReply("⚠️ Couldn't reach the ER:LC server.");
        return;
      }
      await interaction.editReply(
        [
          `**${server.Name}**`,
          `Players: \`${server.CurrentPlayers}/${server.MaxPlayers}\``,
          `Join code: \`${server.JoinKey}\``,
          `Account verification: \`${server.AccVerifiedReq}\``,
          `Team balance: \`${server.TeamBalance ? 'On' : 'Off'}\``,
        ].join('\n')
      );
      return;
    }

    if (interaction.commandName === 'calls') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const calls = await api.getEmergencyCalls();
      const lines = calls.map((c) => {
        const started = `<t:${c.StartedAt}:R>`;
        const desc = c.PositionDescriptor || c.Description || 'No description';
        return `**#${c.CallNumber}** (${c.Team}) — ${desc} — started ${started}`;
      });
      await interaction.editReply(
        `**Active calls (${calls.length}):**\n${formatList(lines, 'No active emergency calls.')}`
      );
      return;
    }

    if (interaction.commandName === 'lookup') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const query = interaction.options.getString('name', true).toLowerCase();

      const [players, queue, staff] = await Promise.all([api.getPlayers(), api.getQueue(), api.getStaff()]);

      const matchedPlayers = players.filter((p) => splitPlayerString(p.Player).name.toLowerCase().includes(query));
      const matchedStaff = staff.filter((s) => s.name.toLowerCase().includes(query));
      const matchedQueue = queue.filter((entry) => {
        if (entry && typeof entry === 'object') return splitPlayerString(entry.Player ?? '').name.toLowerCase().includes(query);
        return false; // queue entries that are bare Roblox IDs can't be name-matched
      });

      const lines = [];
      for (const p of matchedPlayers) {
        const { name } = splitPlayerString(p.Player);
        lines.push(`🟢 **${name}** — in-game (${p.Team ?? 'no team'})`);
      }
      for (const s of matchedStaff) {
        lines.push(`🛡️ **${s.name}** — staff (${s.role})`);
      }
      for (const entry of matchedQueue) {
        const { name } = splitPlayerString(entry.Player ?? '');
        lines.push(`🕓 **${name}** — in queue`);
      }

      await interaction.editReply(
        `**Results for "${interaction.options.getString('name', true)}":**\n${formatList(lines, 'No matches found in players, queue, or staff.')}`
      );
      return;
    }

    if (interaction.commandName === 'teams') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const players = await api.getPlayers();
      const counts = {};
      for (const p of players) {
        const team = p.Team || 'Unknown';
        counts[team] = (counts[team] ?? 0) + 1;
      }
      const lines = Object.entries(counts)
        .sort((a, b) => b[1] - a[1])
        .map(([team, count]) => `**${team}**: ${count}`);
      await interaction.editReply(
        `**Team breakdown (${players.length} total):**\n${formatList(lines, 'Nobody is currently in-game.')}`
      );
      return;
    }

    if (interaction.commandName === 'announce') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const message = interaction.options.getString('message', true);
      await api.runCommand(`:h ${message}`);
      await interaction.editReply(`📢 Announced: "${message}"`);
      return;
    }

    if (interaction.commandName === '911') {
      // Public reply - a dispatch alert is meant to be seen, not hidden from the channel.
      await interaction.deferReply();
      const description = interaction.options.getString('description', true);
      const team = interaction.options.getString('team') ?? 'Unassigned';

      let inGameSent = true;
      try {
        await api.runCommand(`:h 🚨 911 Dispatch (${team}): ${description}`);
      } catch (err) {
        inGameSent = false;
        console.error('Failed to broadcast 911 call in-game:', err.message);
      }

      const lines = [
        '🚨 **New 911 Call**',
        `**Team:** ${team}`,
        `**Description:** ${description}`,
        `**Reported by:** ${interaction.user}`,
      ];
      if (!inGameSent) {
        lines.push("⚠️ Couldn't reach the in-game server to broadcast this — posted here only.");
      }
      await interaction.editReply(lines.join('\n'));
      return;
    }

    if (interaction.commandName === 'setinfractionlog' || interaction.commandName === 'setpromotionlog') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const kind = interaction.commandName === 'setinfractionlog' ? 'infraction' : 'promotion';
      const channel = interaction.options.getChannel('channel') ?? interaction.channel;
      Storage.setLogChannel(interaction.guildId, kind, channel.id);
      await interaction.editReply(`✅ ${kind === 'infraction' ? 'Infraction' : 'Promotion'} notices will now be posted in <#${channel.id}>.`);
      return;
    }

    if (interaction.commandName === 'infraction') {
      const sub = interaction.options.getSubcommand();

      if (sub === 'create') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const target = interaction.options.getUser('user', true);
        const chosenType = interaction.options.getString('type', true);
        const customType = interaction.options.getString('custom_type');
        const type = chosenType === 'Custom' ? (customType || 'Custom') : chosenType;
        const reason = interaction.options.getString('reason', true);

        const record = Storage.addRecord(interaction.guildId, 'infractions', target.id, {
          type,
          reason,
          issuedBy: interaction.user.id,
          issuedByTag: interaction.user.tag,
        });
        const count = Storage.getRecords(interaction.guildId, 'infractions', target.id).length;

        const data = {
          target_tag: target.tag,
          target_mention: `<@${target.id}>`,
          target_id: target.id,
          type,
          reason,
          issuer_tag: interaction.user.tag,
          issuer_mention: `<@${interaction.user.id}>`,
          issuer_id: interaction.user.id,
          count,
          timestamp: record.timestamp,
          date: `<t:${record.timestamp}:F>`,
          date_relative: `<t:${record.timestamp}:R>`,
        };

        const logChannelId = Storage.getLogChannel(interaction.guildId, 'infraction');
        const logChannel = logChannelId
          ? await client.channels.fetch(logChannelId).catch(() => null)
          : interaction.channel;
        const targetChannel = logChannel ?? interaction.channel;

        const { payload, files } = buildNoticePayload('infraction', data);
        await targetChannel.send({ ...payload, files });

        const note = logChannelId && !logChannel ? '\n⚠️ Your configured infraction log channel is missing; posted here instead.' : '';
        await interaction.editReply(`✅ Logged **${type}** for ${target.tag} in <#${targetChannel.id}>.${note}`);
        return;
      }

      if (sub === 'history') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const target = interaction.options.getUser('user', true);
        const records = Storage.getRecords(interaction.guildId, 'infractions', target.id);
        const lines = records.map(
          (r, i) => `**#${i + 1}** ${r.type} — ${r.reason} (by <@${r.issuedBy}>, <t:${r.timestamp}:R>)`
        );
        await interaction.editReply(
          `**Infraction history for ${target.tag} (${records.length}):**\n${formatList(lines, 'No infractions on record.')}`
        );
        return;
      }
    }

    if (interaction.commandName === 'promotion') {
      const sub = interaction.options.getSubcommand();

      if (sub === 'create') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const target = interaction.options.getUser('user', true);
        const to = interaction.options.getString('to', true);
        const from = interaction.options.getString('from') ?? 'N/A';
        const reason = interaction.options.getString('reason') ?? 'No reason provided.';

        const record = Storage.addRecord(interaction.guildId, 'promotions', target.id, {
          from,
          to,
          reason,
          issuedBy: interaction.user.id,
          issuedByTag: interaction.user.tag,
        });

        const data = {
          target_tag: target.tag,
          target_mention: `<@${target.id}>`,
          target_id: target.id,
          from,
          to,
          reason,
          issuer_tag: interaction.user.tag,
          issuer_mention: `<@${interaction.user.id}>`,
          issuer_id: interaction.user.id,
          timestamp: record.timestamp,
          date: `<t:${record.timestamp}:F>`,
          date_relative: `<t:${record.timestamp}:R>`,
        };

        const logChannelId = Storage.getLogChannel(interaction.guildId, 'promotion');
        const logChannel = logChannelId
          ? await client.channels.fetch(logChannelId).catch(() => null)
          : interaction.channel;
        const targetChannel = logChannel ?? interaction.channel;

        const { payload, files } = buildNoticePayload('promotion', data);
        await targetChannel.send({ ...payload, files });

        const note = logChannelId && !logChannel ? '\n⚠️ Your configured promotion log channel is missing; posted here instead.' : '';
        await interaction.editReply(`✅ Logged promotion for ${target.tag} (${from} → ${to}) in <#${targetChannel.id}>.${note}`);
        return;
      }

      if (sub === 'history') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const target = interaction.options.getUser('user', true);
        const records = Storage.getRecords(interaction.guildId, 'promotions', target.id);
        const lines = records.map(
          (r, i) => `**#${i + 1}** ${r.from} → ${r.to} — ${r.reason} (by <@${r.issuedBy}>, <t:${r.timestamp}:R>)`
        );
        await interaction.editReply(
          `**Promotion history for ${target.tag} (${records.length}):**\n${formatList(lines, 'No promotions on record.')}`
        );
        return;
      }
    }

    if (interaction.commandName === 'vcjoin') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const channel = interaction.options.getChannel('channel', true);
      Storage.setVoiceChannel(interaction.guildId, channel.id);
      await joinAndHold(client, interaction.guildId, channel.id);
      await interaction.editReply(
        `🔊 Joined <#${channel.id}> and will stay there — auto-rejoining if disconnected, and rejoining automatically on bot restart too.`
      );
      return;
    }

    if (interaction.commandName === 'vcleave') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      Storage.clearVoiceChannel(interaction.guildId);
      const left = leaveVoice(interaction.guildId);
      await interaction.editReply(left ? '👋 Left the voice channel.' : "I wasn't in a voice channel here.");
      return;
    }
  } catch (err) {
    // Never let a single failed interaction take the whole bot down.
    console.error(`Error handling /${interaction.commandName}:`, err.message);
    const errorMessage = '⚠️ Something went wrong running that command. Check the terminal for details.';
    try {
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(errorMessage);
      } else {
        await interaction.reply({ content: errorMessage, flags: MessageFlags.Ephemeral });
      }
    } catch {
      // The interaction token itself expired (e.g. Discord's "Unknown interaction" 10062) - nothing more we can do.
    }
  }
});

// Safety net: log unexpected errors instead of crashing the whole process.
process.on('unhandledRejection', (err) => {
  console.error('Unhandled rejection:', err);
});
process.on('uncaughtException', (err) => {
  console.error('Uncaught exception:', err);
});

modmail.attach(client, { authorizedIds: AUTHORIZED_IDS });
suggestions.attach(client, { authorizedIds: AUTHORIZED_IDS });
sessionReminders.attach(client, { authorizedIds: AUTHORIZED_IDS });
activity.attach(client, { authorizedIds: AUTHORIZED_IDS });

// ---- Startup ----

client.once('clientReady', () => {
  console.log(`Logged in as ${client.user.tag}`);
  console.log(`Live refresh interval: ${REFRESH_SECONDS}s`);

  refreshAllGuilds();
  setInterval(refreshAllGuilds, REFRESH_SECONDS * 1000);

  updatePresence(client, { api });
  setInterval(() => updatePresence(client, { api }), REFRESH_SECONDS * 1000);

  const voiceBindings = Storage.allVoiceChannels();
  for (const [guildId, channelId] of Object.entries(voiceBindings)) {
    joinAndHold(client, guildId, channelId);
  }
});

client.login(process.env.DISCORD_TOKEN);
