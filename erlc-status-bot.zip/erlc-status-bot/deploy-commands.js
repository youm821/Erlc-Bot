require('dotenv').config();
const { REST, Routes, SlashCommandBuilder, ChannelType } = require('discord.js');

// Commands are visible to everyone in Discord's UI, but only the account
// matching OWNER_ID (checked at runtime in index.js) can actually run them.
// Kept as a wrapper function (rather than removing it everywhere below) so
// the per-command definitions below didn't need to change.
const adminOnly = (builder) => builder;

const commands = [
  adminOnly(
    new SlashCommandBuilder()
      .setName('setstatus')
      .setDescription('Post (or move) the live ER:LC status embed in this channel.')
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('statusrefresh')
      .setDescription('Force an immediate refresh of the live ER:LC status embed.')
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('statusstop')
      .setDescription('Stop and remove the live status feed for this server.')
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('players')
      .setDescription('List who is currently in-game on the ER:LC server.')
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('queue')
      .setDescription("List who's currently waiting in the join queue.")
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('bans')
      .setDescription('List currently banned players.')
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('command')
      .setDescription('Run an in-game ER:LC command (e.g. :h Hello everyone!).')
      .addStringOption((option) =>
        option
          .setName('text')
          .setDescription('The command to run, including the leading colon (e.g. :h Hello!)')
          .setRequired(true)
      )
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('presence')
      .setDescription("Manually set/refresh the bot's Discord status text.")
      .addStringOption((option) =>
        option
          .setName('text')
          .setDescription('Custom status text. Leave blank to auto-fill with live player count.')
          .setRequired(false)
      )
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('staff')
      .setDescription('List currently online server staff (admins/mods).')
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('vehicles')
      .setDescription('List vehicles currently spawned in-game.')
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('killlogs')
      .setDescription('Show recent kill logs.')
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('commandlogs')
      .setDescription('Show recent staff/admin command usage.')
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('joinlogs')
      .setDescription('Show recent join/leave activity.')
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('serverinfo')
      .setDescription('Quick one-off snapshot of server info (no live embed).')
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('calls')
      .setDescription('List active emergency/priority calls.')
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('lookup')
      .setDescription('Check if a player is currently in-game, queued, or staff.')
      .addStringOption((option) =>
        option
          .setName('name')
          .setDescription('Roblox username to search for (partial match works).')
          .setRequired(true)
      )
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('teams')
      .setDescription('Player count broken down by team.')
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('announce')
      .setDescription('Sends an in-game hint announcement (:h) to the server.')
      .addStringOption((option) =>
        option
          .setName('message')
          .setDescription('The announcement text.')
          .setRequired(true)
      )
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('911')
      .setDescription('Post a dispatch alert in this channel and broadcast it in-game.')
      .addStringOption((option) =>
        option
          .setName('description')
          .setDescription('What is the call about, and where?')
          .setRequired(true)
      )
      .addStringOption((option) =>
        option
          .setName('team')
          .setDescription('Which department should respond?')
          .setRequired(false)
          .addChoices(
            { name: 'Police', value: 'Police' },
            { name: 'Fire', value: 'Fire' },
            { name: 'EMS', value: 'EMS' }
          )
      )
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('setinfractionlog')
      .setDescription('Set which channel infraction notices get posted to.')
      .addChannelOption((option) =>
        option
          .setName('channel')
          .setDescription('Defaults to the channel this command is run in.')
          .addChannelTypes(ChannelType.GuildText)
          .setRequired(false)
      )
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('setpromotionlog')
      .setDescription('Set which channel promotion notices get posted to.')
      .addChannelOption((option) =>
        option
          .setName('channel')
          .setDescription('Defaults to the channel this command is run in.')
          .addChannelTypes(ChannelType.GuildText)
          .setRequired(false)
      )
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('infraction')
      .setDescription('Manage staff infractions.')
      .addSubcommand((sub) =>
        sub
          .setName('create')
          .setDescription('Log a new infraction for a staff member.')
          .addUserOption((o) => o.setName('user').setDescription('The staff member.').setRequired(true))
          .addStringOption((o) =>
            o
              .setName('type')
              .setDescription('Infraction type.')
              .setRequired(true)
              .addChoices(
                { name: 'Verbal Warning', value: 'Verbal Warning' },
                { name: 'Written Warning', value: 'Written Warning' },
                { name: 'Strike', value: 'Strike' },
                { name: 'Suspension', value: 'Suspension' },
                { name: 'Termination', value: 'Termination' },
                { name: 'Custom', value: 'Custom' }
              )
          )
          .addStringOption((o) => o.setName('reason').setDescription('Reason for the infraction.').setRequired(true))
          .addStringOption((o) =>
            o.setName('custom_type').setDescription('If Type is Custom, type the label here.').setRequired(false)
          )
      )
      .addSubcommand((sub) =>
        sub
          .setName('history')
          .setDescription("View a staff member's infraction history.")
          .addUserOption((o) => o.setName('user').setDescription('The staff member.').setRequired(true))
      )
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('promotion')
      .setDescription('Manage staff promotions.')
      .addSubcommand((sub) =>
        sub
          .setName('create')
          .setDescription('Log a new promotion for a staff member.')
          .addUserOption((o) => o.setName('user').setDescription('The staff member.').setRequired(true))
          .addStringOption((o) => o.setName('to').setDescription('New rank/role.').setRequired(true))
          .addStringOption((o) => o.setName('from').setDescription('Previous rank/role.').setRequired(false))
          .addStringOption((o) => o.setName('reason').setDescription('Reason for the promotion.').setRequired(false))
      )
      .addSubcommand((sub) =>
        sub
          .setName('history')
          .setDescription("View a staff member's promotion history.")
          .addUserOption((o) => o.setName('user').setDescription('The staff member.').setRequired(true))
      )
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('vcjoin')
      .setDescription('Join a voice channel and stay there 24/7, auto-rejoining if disconnected.')
      .addChannelOption((option) =>
        option
          .setName('channel')
          .setDescription('The voice channel to join and hold.')
          .addChannelTypes(ChannelType.GuildVoice)
          .setRequired(true)
      )
  ),

  adminOnly(
    new SlashCommandBuilder()
      .setName('vcleave')
      .setDescription('Leave the voice channel and stop auto-rejoining.')
  ),
  ...require('./modmail').commands,
  ...require('./suggestions').commands,
  ...require('./sessionReminders').commands,
  ...require('./activity').commands,
].map((c) => c.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log(`Registering ${commands.length} slash commands...`);
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commands });
    console.log('Slash commands registered successfully.');
  } catch (err) {
    console.error('Failed to register commands:', err);
    process.exit(1);
  }
})();
