const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');

const STATUS_TEMPLATE_PATH = path.join(__dirname, 'template.json');
const INFRACTION_TEMPLATE_PATH = path.join(__dirname, 'infractionTemplate.json');
const PROMOTION_TEMPLATE_PATH = path.join(__dirname, 'promotionTemplate.json');
const SUGGESTION_TEMPLATE_PATH = path.join(__dirname, 'suggestionTemplate.json');

function fileExists(p) {
  return fs.existsSync(p);
}

function loadRaw(p) {
  return JSON.parse(fs.readFileSync(p, 'utf8'));
}

/** Recursively replaces {{placeholder}} tokens in every string value of an object/array. */
function fillPlaceholders(value, data) {
  if (typeof value === 'string') {
    return value.replace(/\{\{\s*([\w.]+)\s*\}\}/g, (match, key) => {
      const replacement = data[key];
      return replacement !== undefined && replacement !== null ? String(replacement) : match;
    });
  }
  if (Array.isArray(value)) {
    return value.map((item) => fillPlaceholders(item, data));
  }
  if (value && typeof value === 'object') {
    const result = {};
    for (const [key, val] of Object.entries(value)) {
      result[key] = fillPlaceholders(val, data);
    }
    return result;
  }
  return value;
}

/**
 * Scans any nested object for "attachment://filename" string values (image
 * urls, thumbnail urls, file references, etc.) so index.js knows which local
 * files under /assets to attach to the message.
 */
function collectAttachmentFilenames(node) {
  const names = new Set();
  const scan = (obj) => {
    if (!obj || typeof obj !== 'object') return;
    for (const value of Object.values(obj)) {
      if (typeof value === 'string' && value.startsWith('attachment://')) {
        names.add(value.replace('attachment://', ''));
      } else if (value && typeof value === 'object') {
        scan(value);
      }
    }
  };
  scan(node);
  return [...names];
}

/**
 * Turns a parsed Discohook-style export + a flat placeholder data object into
 * a payload describing what to send. Supports:
 *
 *  - Components V2 (Discohook export using containers, text displays, media
 *    galleries, etc.): { flags: 32768, components: [...] }
 *  - Classic embeds (older-style Discohook exports / hand-written JSON):
 *    { embeds: [...] } or { messages: [ { data: { embeds: [...] } } ] }
 *
 * This is the shared engine used by the status card, infraction notices, and
 * promotion notices - any of them can be a hand-edited Discohook JSON export.
 */
function buildPayloadFromParsedTemplate(parsed, data) {
  // --- Components V2 export ---
  if (Array.isArray(parsed.components)) {
    const filledComponents = fillPlaceholders(parsed.components, data);
    const attachmentFilenames = collectAttachmentFilenames(parsed.components);
    return {
      mode: 'components_v2',
      flags: parsed.flags,
      components: filledComponents,
      attachmentFilenames,
    };
  }

  // --- Classic embeds export ---
  let rawEmbeds;
  if (Array.isArray(parsed?.messages) && parsed.messages[0]?.data) {
    rawEmbeds = parsed.messages[0].data.embeds ?? [];
  } else if (Array.isArray(parsed?.embeds)) {
    rawEmbeds = parsed.embeds;
  } else if (Array.isArray(parsed)) {
    rawEmbeds = parsed;
  } else {
    throw new Error('Template is not in a recognized format.');
  }

  const filled = fillPlaceholders(rawEmbeds, data);
  const embeds = filled.map((embedData) => new EmbedBuilder(embedData));
  const attachmentFilenames = collectAttachmentFilenames(rawEmbeds);
  return { mode: 'embeds', embeds, attachmentFilenames };
}

/** Builds the data object made available to {{placeholders}} in the status template. */
function buildPlaceholderData(snapshot) {
  const { server, players, queue } = snapshot;

  const playerCount = server?.CurrentPlayers ?? players?.length ?? 0;
  const maxPlayers = server?.MaxPlayers ?? 0;
  const queueCount = Array.isArray(queue) ? queue.length : 0;
  const pctFull = maxPlayers > 0 ? Math.round((playerCount / maxPlayers) * 100) : 0;
  const isFull = playerCount >= maxPlayers && maxPlayers > 0;
  const isBusy = !isFull && pctFull >= 75;

  return {
    server_name: server?.Name ?? 'Unknown',
    players: playerCount,
    max_players: maxPlayers,
    queue: queueCount,
    team_balance: server?.TeamBalance ? 'Enabled' : 'Disabled',
    verification: server?.AccVerifiedReq ?? 'Unknown',
    join_key: server?.JoinKey ?? 'N/A',
    status: isFull ? '🔴 Full' : isBusy ? '🟡 Busy' : '🟢 Open',
    status_plain: isFull ? 'Full' : isBusy ? 'Busy' : 'Open',
    percent_full: pctFull,
    updated_relative: `<t:${Math.floor(Date.now() / 1000)}:R>`,
    updated_time: `<t:${Math.floor(Date.now() / 1000)}:t>`,
  };
}

// ---- Status card (existing template.json) ----

function templateExists() {
  return fileExists(STATUS_TEMPLATE_PATH);
}

function buildFromTemplate(snapshot) {
  const parsed = loadRaw(STATUS_TEMPLATE_PATH);
  const data = buildPlaceholderData(snapshot);
  return buildPayloadFromParsedTemplate(parsed, data);
}

// ---- Infraction notices (optional infractionTemplate.json) ----

function infractionTemplateExists() {
  return fileExists(INFRACTION_TEMPLATE_PATH);
}

/**
 * data should contain: target_tag, target_mention, type, reason, issuer_tag,
 * issuer_mention, count, date, date_relative (see index.js for how these are built).
 */
function buildFromInfractionTemplate(data) {
  const parsed = loadRaw(INFRACTION_TEMPLATE_PATH);
  return buildPayloadFromParsedTemplate(parsed, data);
}

// ---- Promotion notices (optional promotionTemplate.json) ----

function promotionTemplateExists() {
  return fileExists(PROMOTION_TEMPLATE_PATH);
}

/**
 * data should contain: target_tag, target_mention, from, to, reason,
 * issuer_tag, issuer_mention, date, date_relative.
 */
function buildFromPromotionTemplate(data) {
  const parsed = loadRaw(PROMOTION_TEMPLATE_PATH);
  return buildPayloadFromParsedTemplate(parsed, data);
}

// ---- Suggestions (optional suggestionTemplate.json) ----

function suggestionTemplateExists() {
  return fileExists(SUGGESTION_TEMPLATE_PATH);
}

/**
 * data should contain: author_tag, author_mention, suggestion, number,
 * date, date_relative (see suggestions.js for how these are built).
 */
function buildFromSuggestionTemplate(data) {
  const parsed = loadRaw(SUGGESTION_TEMPLATE_PATH);
  return buildPayloadFromParsedTemplate(parsed, data);
}

module.exports = {
  templateExists,
  buildFromTemplate,
  infractionTemplateExists,
  buildFromInfractionTemplate,
  promotionTemplateExists,
  buildFromPromotionTemplate,
  suggestionTemplateExists,
  buildFromSuggestionTemplate,
};
