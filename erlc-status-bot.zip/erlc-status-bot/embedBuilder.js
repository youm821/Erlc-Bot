const { EmbedBuilder } = require('discord.js');

// Display name shown in the status card, independent of the raw ER:LC server name.
const SERVER_DISPLAY_NAME = 'Florida State Roleplay';

// These reference files attached to the message via AttachmentBuilder (see index.js).
// Discord resolves "attachment://<filename>" to whatever file with that name was
// uploaded alongside the message - no external image hosting needed.
const TOP_BANNER_ATTACHMENT = 'attachment://banner_top.png';
const BOTTOM_BANNER_ATTACHMENT = 'attachment://banner_bottom.png';

/**
 * Turns an ERLCApi snapshot into a 3-part embed stack:
 *   1. Top banner image
 *   2. Main status card (title, fields, footer)
 *   3. Bottom banner image
 * Discord renders multiple embeds in one message stacked vertically, which is
 * how the "banner / content / banner" layout is achieved.
 */
function buildStatusEmbeds(snapshot, { refreshSeconds } = {}) {
  const { server, players, queue, errors } = snapshot;

  const topBanner = new EmbedBuilder()
    .setColor(0x2b2d31)
    .setImage(TOP_BANNER_ATTACHMENT);

  const bottomBanner = new EmbedBuilder()
    .setColor(0x2b2d31)
    .setImage(BOTTOM_BANNER_ATTACHMENT);

  if (!server) {
    const errorCard = new EmbedBuilder()
      .setTitle(`🚓 ${SERVER_DISPLAY_NAME}`)
      .setColor(0xe74c3c)
      .setDescription(
        "⚠️ Couldn't reach the ER:LC API right now. Will retry on the next refresh."
      )
      .setTimestamp();
    return [topBanner, errorCard, bottomBanner];
  }

  const playerCount = server.CurrentPlayers ?? players.length ?? 0;
  const maxPlayers = server.MaxPlayers ?? 0;
  const queueCount = Array.isArray(queue) ? queue.length : 0;
  const pctFull = maxPlayers > 0 ? Math.round((playerCount / maxPlayers) * 100) : 0;

  const color = playerCount >= maxPlayers && maxPlayers > 0
    ? 0xe74c3c // full - red
    : pctFull >= 75
      ? 0xf1c40f // busy - yellow
      : 0x2ecc71; // open - green

  const statusCard = new EmbedBuilder()
    .setTitle(`🚓 ${SERVER_DISPLAY_NAME}`)
    .setColor(color)
    .addFields(
      { name: 'Players', value: `${playerCount}/${maxPlayers}`, inline: true },
      { name: 'Queue', value: `${queueCount}`, inline: true },
      { name: 'Team Balance', value: server.TeamBalance ? 'Enabled' : 'Disabled', inline: true },
      { name: 'Account Verification', value: server.AccVerifiedReq ?? 'Unknown', inline: true },
      { name: 'Join Key', value: server.JoinKey ? `\`${server.JoinKey}\`` : 'N/A', inline: true },
      { name: 'Status', value: playerCount >= maxPlayers && maxPlayers > 0 ? '🔴 Full' : pctFull >= 75 ? '🟡 Busy' : '🟢 Open', inline: true },
      { name: 'Last Updated', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
    )
    .setFooter({
      text: refreshSeconds
        ? `Live feed • refreshes every ${refreshSeconds}s • Last updated`
        : 'Last updated',
    })
    .setTimestamp();

  if (errors?.length) {
    statusCard.addFields({
      name: '⚠️ Partial data',
      value: 'Some info (players/queue) failed to load this refresh.',
    });
  }

  return [topBanner, statusCard, bottomBanner];
}

const INFRACTION_COLORS = {
  'Verbal Warning': 0xf1c40f,
  'Written Warning': 0xe67e22,
  'Strike': 0xe74c3c,
  'Suspension': 0x992d22,
  'Termination': 0x2c2f33,
};

/** Default infraction notice design, used until an infractionTemplate.json is provided. */
function buildInfractionEmbed({ target_tag, type, reason, issuer_tag, timestamp, count }) {
  const embed = new EmbedBuilder()
    .setTitle(`📋 Staff Infraction — ${type}`)
    .setColor(INFRACTION_COLORS[type] ?? 0xe74c3c)
    .addFields(
      { name: 'Staff Member', value: target_tag, inline: true },
      { name: 'Type', value: type, inline: true },
      { name: 'Issued By', value: issuer_tag, inline: true },
      { name: 'Reason', value: reason || 'No reason provided.' },
    )
    .setFooter({ text: count ? `Infraction #${count} on record` : 'Logged' })
    .setTimestamp(new Date(timestamp * 1000));
  return { embeds: [embed] };
}

/** Default promotion notice design, used until a promotionTemplate.json is provided. */
function buildPromotionEmbed({ target_tag, from, to, reason, issuer_tag, timestamp }) {
  const embed = new EmbedBuilder()
    .setTitle('🎉 Staff Promotion')
    .setColor(0x2ecc71)
    .addFields(
      { name: 'Staff Member', value: target_tag, inline: true },
      { name: 'From', value: from || 'N/A', inline: true },
      { name: 'To', value: to, inline: true },
      { name: 'Issued By', value: issuer_tag, inline: true },
      { name: 'Reason', value: reason || 'No reason provided.' },
    )
    .setTimestamp(new Date(timestamp * 1000));
  return { embeds: [embed] };
}

module.exports = { buildStatusEmbeds, buildInfractionEmbed, buildPromotionEmbed };
