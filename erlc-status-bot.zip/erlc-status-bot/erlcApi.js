const BASE_URL = 'https://api.erlc.gg/v2';

/**
 * Thin wrapper around the ER:LC / PRC public API (v2).
 * Docs: https://apidocs.erlc.gg/
 *
 * IMPORTANT: v2 does NOT have separate /server/players, /server/queue,
 * /server/killlogs, /server/commandlogs, /server/joinlogs endpoints like
 * v1 did. Instead, everything is requested from a single GET /server call
 * with boolean query flags (?Players=true&Queue=true&...), and the extra
 * data comes back as fields on the same response object.
 */
class ERLCApi {
  constructor(serverKey) {
    if (!serverKey) throw new Error('ERLC_SERVER_KEY is required');
    this.serverKey = serverKey;
  }

  async #request(path, { method = 'GET', body, query } = {}) {
    const url = new URL(`${BASE_URL}${path}`);
    if (query) {
      for (const [key, value] of Object.entries(query)) {
        if (value !== undefined) url.searchParams.set(key, String(value));
      }
    }

    const res = await fetch(url, {
      method,
      headers: {
        'Server-Key': this.serverKey,
        'Accept': 'application/json',
        ...(body ? { 'Content-Type': 'application/json' } : {}),
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });

    if (res.status === 429) {
      const retryAfter = res.headers.get('retry-after');
      throw new Error(`Rate limited by ER:LC API. Retry after ${retryAfter ?? '?'}s`);
    }

    if (!res.ok) {
      let errBody;
      try { errBody = await res.json(); } catch { errBody = await res.text(); }
      throw new Error(`ER:LC API error ${res.status} on ${path}: ${JSON.stringify(errBody)}`);
    }

    // Command endpoint returns 200 with no/empty body on success.
    const text = await res.text();
    return text ? JSON.parse(text) : null;
  }

  /**
   * Core server status call. Pass flags to include extra data in the same
   * response, e.g. getServer({ Players: true, Queue: true }).
   * Available flags: Players, Staff, JoinLogs, Queue, KillLogs, CommandLogs, Vehicles.
   */
  getServer(flags = {}) {
    return this.#request('/server', { query: flags });
  }

  /** Array of players currently in-game (name, permission, callsign, team). */
  async getPlayers() {
    const data = await this.getServer({ Players: true });
    return data?.Players ?? [];
  }

  /** Array of Roblox IDs currently waiting in the join queue. */
  async getQueue() {
    const data = await this.getServer({ Queue: true });
    return data?.Queue ?? [];
  }

  /** Recent kill logs. */
  async getKillLogs() {
    const data = await this.getServer({ KillLogs: true });
    return data?.KillLogs ?? [];
  }

  /** Recent mod/admin command logs. */
  async getCommandLogs() {
    const data = await this.getServer({ CommandLogs: true });
    return data?.CommandLogs ?? [];
  }

  /** Recent join/leave logs. */
  async getJoinLogs() {
    const data = await this.getServer({ JoinLogs: true });
    return data?.JoinLogs ?? [];
  }

  /**
   * Currently online staff (moderators/admins), flattened into a single list.
   * The raw API response nests these by role: { Admins: {id:name}, Mods: {id:name}, ... }.
   */
  async getStaff() {
    const data = await this.getServer({ Staff: true });
    const staff = data?.Staff ?? {};
    const flattened = [];
    for (const [role, members] of Object.entries(staff)) {
      if (!members || typeof members !== 'object') continue;
      for (const [id, name] of Object.entries(members)) {
        flattened.push({ id, name, role });
      }
    }
    return flattened;
  }

  /** Vehicles currently spawned/in-use in-game. */
  async getVehicles() {
    const data = await this.getServer({ Vehicles: true });
    return data?.Vehicles ?? [];
  }

  /** Active emergency/priority calls (Team, Caller Roblox ID, Position, Description, etc.). */
  async getEmergencyCalls() {
    const data = await this.getServer({ EmergencyCalls: true });
    return data?.EmergencyCalls ?? [];
  }

  /**
   * Currently banned players. NOTE: ER:LC bans now go through Roblox's own
   * account ban system, so this endpoint may not exist/return data for
   * every server. Handle a failure here gracefully.
   */
  getBans() {
    return this.#request('/server/bans');
  }

  /**
   * Runs an in-game ER:LC command (e.g. ":h Hello everyone!").
   * Rate limited to roughly 1 request per 5 seconds by the API.
   */
  runCommand(command) {
    return this.#request('/server/command', { method: 'POST', body: { command } });
  }

  /** Fetches everything the status embed needs in one go, tolerating partial failures. */
  async getSnapshot() {
    const result = await this.getServer({ Players: true, Queue: true }).catch((err) => err);

    if (result instanceof Error) {
      console.error('ER:LC API request failed:', result.message);
      return { server: null, players: [], queue: [], errors: [result.message] };
    }

    return {
      server: result,
      players: result?.Players ?? [],
      queue: result?.Queue ?? [],
      errors: [],
    };
  }
}

module.exports = { ERLCApi };
