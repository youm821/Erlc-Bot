const { ActivityType } = require('discord.js');

/**
 * Sets the bot's own Discord status/activity (the "Playing X" text under its
 * name in the member list).
 *
 * NOTE: bot accounts can only set a simple activity name + type (Playing,
 * Watching, Listening, Competing, or a Custom Status). The full "Rich
 * Presence" feature set - party size, join secrets, start/end timestamps,
 * large/small images - is only available to games running the Discord Game
 * SDK on a real user's account. There is no bot-API equivalent for those
 * fields, so they can't be added here no matter how the text is phrased.
 *
 * @param client  The logged-in discord.js Client.
 * @param options.text  Exact text to show. If omitted, falls back to a live
 *   player-count string built from `api`.
 * @param options.api   ERLCApi instance, used only when `text` isn't given.
 * @param options.type  discord.js ActivityType (defaults to Playing).
 */
async function updatePresence(client, { text, api, type = ActivityType.Playing } = {}) {
  if (!client.user) {
    console.warn('[presence] Skipped: client.user is not ready yet.');
    return { ok: false, reason: 'Client not ready yet.' };
  }

  let name = text;
  if (!name) {
    try {
      const snapshot = await api.getSnapshot();
      name = snapshot.server
        ? `FSRP — ${snapshot.server.CurrentPlayers}/${snapshot.server.MaxPlayers} players`
        : 'FSRP';
    } catch (err) {
      console.error('[presence] Failed to fetch ER:LC snapshot for presence text:', err.message);
      return { ok: false, reason: `Couldn't reach the ER:LC API: ${err.message}` };
    }
  }

  try {
    client.user.setPresence({
      activities: [{ name, type }],
      status: 'online',
    });
    console.log(`[presence] Set to "${name}".`);
    return { ok: true, name };
  } catch (err) {
    console.error('[presence] client.user.setPresence() threw:', err.message);
    return { ok: false, reason: err.message };
  }
}

module.exports = { updatePresence };
