const { SlashCommandBuilder, ChannelType, EmbedBuilder, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, 'session-reminders-data.json');
const CHECK_INTERVAL_MS = 30_000;

function load() {
  if (!fs.existsSync(DATA_FILE)) return { config: {} };
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch {
    return { config: {} };
  }
}

function save(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function getGuildConfig(guildId) {
  const data = load();
  return data.config[guildId] ?? { channelId: null, reminders: [] };
}

function setChannel(guildId, channelId) {
  const data = load();
  if (!data.config[guildId]) data.config[guildId] = { channelId: null, reminders: [] };
  data.config[guildId].channelId = channelId;
  save(data);
}

/** time is "HH:MM" in 24-hour UTC. */
function addReminder(guildId, time, message) {
  const data = load();
  if (!data.config[guildId]) data.config[guildId] = { channelId: null, reminders: [] };
  const reminder = { id: Date.now().toString(36), time, message, lastFiredDate: null };
  data.config[guildId].reminders.push(reminder);
  save(data);
  return reminder;
}

function removeReminder(guildId, time) {
  const data = load();
  const cfg = data.config[guildId];
  if (!cfg) return false;
  const before = cfg.reminders.length;
  cfg.reminders = cfg.reminders.filter((r) => r.time !== time);
  save(data);
  return cfg.reminders.length < before;
}

function listReminders(guildId) {
  return getGuildConfig(guildId).reminders;
}

function isValidTime(time) {
  return /^([01]\d|2[0-3]):([0-5]\d)$/.test(time);
}

/** Marks a reminder as fired today, persisting immediately so a restart mid-day doesn't double-fire it. */
function markFired(guildId, reminderId, dateStr) {
  const data = load();
  const cfg = data.config[guildId];
  if (!cfg) return;
  const reminder = cfg.reminders.find((r) => r.id === reminderId);
  if (reminder) {
    reminder.lastFiredDate = dateStr;
    save(data);
  }
}

function currentUtcHHMM(now) {
  return `${String(now.getUTCHours()).padStart(2, '0')}:${String(now.getUTCMinutes()).padStart(2, '0')}`;
}

function todayUtcDateStr(now) {
  return now.toISOString().slice(0, 10); // "YYYY-MM-DD"
}

/**
 * Wires up scheduled session reminders. Call once after the client is created:
 *   sessionReminders.attach(client, { authorizedIds: AUTHORIZED_IDS });
 * Times are configured in 24-hour UTC (e.g. "19:00").
 */
function attach(client, { authorizedIds } = {}) {
  // ---- Slash commands ----
  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (!['setsessionreminderchannel', 'addsessionreminder', 'removesessionreminder', 'listsessionreminders'].includes(interaction.commandName)) {
      return;
    }

    try {
      if (!authorizedIds?.has(interaction.user.id)) {
        await interaction.reply({ content: "You're not authorized to configure this.", flags: MessageFlags.Ephemeral });
        return;
      }

      if (interaction.commandName === 'setsessionreminderchannel') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const channel = interaction.options.getChannel('channel', true);
        setChannel(interaction.guildId, channel.id);
        await interaction.editReply(`✅ Session reminders will post in <#${channel.id}>.`);
        return;
      }

      if (interaction.commandName === 'addsessionreminder') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const time = interaction.options.getString('time', true).trim();
        if (!isValidTime(time)) {
          await interaction.editReply('⚠️ Time must be in 24-hour UTC format, like `19:00` or `08:30`.');
          return;
        }
        const config = getGuildConfig(interaction.guildId);
        if (!config.channelId) {
          await interaction.editReply('⚠️ Set a channel first with /setsessionreminderchannel.');
          return;
        }
        const message = interaction.options.getString('message') ?? '🚨 Session starting soon — get ready!';
        addReminder(interaction.guildId, time, message);
        await interaction.editReply(`✅ Reminder added for **${time} UTC** (fires daily) in <#${config.channelId}>.`);
        return;
      }

      if (interaction.commandName === 'removesessionreminder') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const time = interaction.options.getString('time', true).trim();
        const removed = removeReminder(interaction.guildId, time);
        await interaction.editReply(removed ? `✅ Removed the **${time} UTC** reminder.` : `No reminder found for **${time} UTC**.`);
        return;
      }

      if (interaction.commandName === 'listsessionreminders') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const reminders = listReminders(interaction.guildId);
        if (!reminders.length) {
          await interaction.editReply('No session reminders configured.');
          return;
        }
        const lines = reminders.map((r) => `**${r.time} UTC** — ${r.message}`);
        await interaction.editReply(`**Configured reminders:**\n${lines.join('\n')}`);
        return;
      }
    } catch (err) {
      console.error(`[sessionReminders] Error handling /${interaction.commandName}:`, err.message);
      const msg = '⚠️ Something went wrong with that command.';
      try {
        if (interaction.deferred || interaction.replied) await interaction.editReply(msg);
        else await interaction.reply({ content: msg, flags: MessageFlags.Ephemeral });
      } catch {
        // interaction token expired - nothing more we can do
      }
    }
  });

  // ---- Scheduler ----
  setInterval(async () => {
    const now = new Date();
    const hhmm = currentUtcHHMM(now);
    const today = todayUtcDateStr(now);
    const data = load();

    for (const [guildId, config] of Object.entries(data.config)) {
      if (!config.channelId || !config.reminders?.length) continue;

      for (const reminder of config.reminders) {
        if (reminder.time !== hhmm) continue;
        if (reminder.lastFiredDate === today) continue; // already fired today

        markFired(guildId, reminder.id, today);
        try {
          const channel = await client.channels.fetch(config.channelId).catch(() => null);
          if (!channel) continue;
          await channel.send({
            embeds: [new EmbedBuilder().setTitle('📢 Session Reminder').setDescription(reminder.message).setColor(0xf1c40f).setTimestamp()],
          });
        } catch (err) {
          console.error(`[sessionReminders] Failed to post reminder in guild ${guildId}:`, err.message);
        }
      }
    }
  }, CHECK_INTERVAL_MS);
}

const commands = [
  new SlashCommandBuilder()
    .setName('setsessionreminderchannel')
    .setDescription('Set which channel session reminders post to. (Staff only)')
    .addChannelOption((o) =>
      o.setName('channel').setDescription('Channel for reminders.').addChannelTypes(ChannelType.GuildText).setRequired(true)
    ),

  new SlashCommandBuilder()
    .setName('addsessionreminder')
    .setDescription('Add a daily recurring session reminder. (Staff only)')
    .addStringOption((o) => o.setName('time').setDescription('24-hour UTC time, e.g. 19:00').setRequired(true))
    .addStringOption((o) => o.setName('message').setDescription('Custom reminder text.').setRequired(false)),

  new SlashCommandBuilder()
    .setName('removesessionreminder')
    .setDescription('Remove a session reminder. (Staff only)')
    .addStringOption((o) => o.setName('time').setDescription('24-hour UTC time to remove, e.g. 19:00').setRequired(true)),

  new SlashCommandBuilder().setName('listsessionreminders').setDescription('List configured session reminders. (Staff only)'),
];

module.exports = { attach, commands };
