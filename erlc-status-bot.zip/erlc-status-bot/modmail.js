const { SlashCommandBuilder, ChannelType, EmbedBuilder, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, 'modmail-data.json');

function load() {
  if (!fs.existsSync(DATA_FILE)) return { config: {}, tickets: {} };
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch {
    return { config: {}, tickets: {} };
  }
}

function save(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function getConfig(guildId) {
  const data = load();
  return data.config[guildId] || null;
}

function setChannel(guildId, channelId) {
  const data = load();
  data.config[guildId] = { ...(data.config[guildId] || {}), channelId };
  save(data);
}

function setRole(guildId, roleId) {
  const data = load();
  data.config[guildId] = { ...(data.config[guildId] || {}), roleId };
  save(data);
}

function getTicket(userId) {
  const data = load();
  return data.tickets[userId] || null;
}

function openTicket(userId, guildId, threadId) {
  const data = load();
  data.tickets[userId] = { guildId, threadId, status: 'open', createdAt: Math.floor(Date.now() / 1000) };
  save(data);
  return data.tickets[userId];
}

function closeTicket(userId) {
  const data = load();
  if (data.tickets[userId]) {
    data.tickets[userId].status = 'closed';
    data.tickets[userId].closedAt = Math.floor(Date.now() / 1000);
    save(data);
  }
}

function findTicketByThread(threadId) {
  const data = load();
  for (const [userId, ticket] of Object.entries(data.tickets)) {
    if (ticket.threadId === threadId) return { userId, ticket };
  }
  return null;
}

/** Figures out which configured guild a DMing user belongs to (handles the common single-guild case instantly). */
async function resolveGuildForUser(client, userId) {
  const data = load();
  const guildIds = Object.keys(data.config).filter((gid) => data.config[gid].channelId);
  if (guildIds.length === 0) return null;
  if (guildIds.length === 1) return guildIds[0];

  for (const gid of guildIds) {
    const guild = client.guilds.cache.get(gid);
    if (!guild) continue;
    const member = await guild.members.fetch(userId).catch(() => null);
    if (member) return gid;
  }
  return guildIds[0]; // fallback if we couldn't confirm membership anywhere
}

async function getOrCreateThread(client, guildId, userId, userTag) {
  const ticket = getTicket(userId);
  if (ticket && ticket.status === 'open') {
    const thread = await client.channels.fetch(ticket.threadId).catch(() => null);
    if (thread) return thread;
    // thread was deleted on Discord's side - fall through and recreate one
  }

  const config = getConfig(guildId);
  if (!config?.channelId) return null;
  const parent = await client.channels.fetch(config.channelId).catch(() => null);
  if (!parent) return null;

  const thread = await parent.threads.create({
    name: `modmail-${userTag}`.slice(0, 100),
    autoArchiveDuration: 10080, // 7 days
    type: ChannelType.PublicThread,
    reason: `Mod mail ticket for ${userTag}`,
  });

  openTicket(userId, guildId, thread.id);

  await thread.send({
    embeds: [
      new EmbedBuilder()
        .setTitle('📬 New Mod Mail Ticket')
        .setDescription(
          `From: <@${userId}> (${userTag})\nOnly staff with the configured mod mail role can reply here — their messages get relayed to the user's DMs.\n\nRun \`/close\` in this thread to close the ticket.`
        )
        .setColor(0x5865f2)
        .setTimestamp(),
    ],
  });

  return thread;
}

function hasModmailRole(member, roleId) {
  if (!roleId || !member) return false;
  return member.roles.cache.has(roleId);
}

/**
 * Wires up mod mail. Call once after the client is created:
 *   modmail.attach(client, { authorizedIds: AUTHORIZED_IDS });
 * `authorizedIds` (a Set of user IDs) can always configure/close tickets in
 * addition to whoever holds the configured mod mail role.
 */
function attach(client, { authorizedIds } = {}) {
  // ---- Slash commands ----
  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (!['modmail', 'setmodmailchannel', 'setmodmailrole', 'close'].includes(interaction.commandName)) return;

    try {
      if (interaction.commandName === 'setmodmailchannel') {
        if (!authorizedIds?.has(interaction.user.id)) {
          await interaction.reply({ content: "You're not authorized to configure mod mail.", flags: MessageFlags.Ephemeral });
          return;
        }
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const channel = interaction.options.getChannel('channel', true);
        setChannel(interaction.guildId, channel.id);
        await interaction.editReply(`✅ Mod mail tickets will be created as threads under <#${channel.id}>.`);
        return;
      }

      if (interaction.commandName === 'setmodmailrole') {
        if (!authorizedIds?.has(interaction.user.id)) {
          await interaction.reply({ content: "You're not authorized to configure mod mail.", flags: MessageFlags.Ephemeral });
          return;
        }
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const role = interaction.options.getRole('role', true);
        setRole(interaction.guildId, role.id);
        await interaction.editReply(`✅ Only members with **${role.name}** can now reply to mod mail tickets.`);
        return;
      }

      if (interaction.commandName === 'modmail') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const guildId = interaction.guildId;
        const config = getConfig(guildId);
        if (!config?.channelId) {
          await interaction.editReply("⚠️ Mod mail isn't set up in this server yet. Ask an admin to run /setmodmailchannel.");
          return;
        }
        const message = interaction.options.getString('message', true);
        const thread = await getOrCreateThread(client, guildId, interaction.user.id, interaction.user.tag);
        if (!thread) {
          await interaction.editReply("⚠️ Couldn't reach the mod mail channel. Ask an admin to check /setmodmailchannel.");
          return;
        }
        await thread.send({
          embeds: [
            new EmbedBuilder()
              .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
              .setDescription(message)
              .setColor(0x2ecc71)
              .setTimestamp(),
          ],
        });
        await interaction.editReply('✅ Your message has been sent to staff. They may reply here or in your DMs.');
        return;
      }

      if (interaction.commandName === 'close') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const found = findTicketByThread(interaction.channelId);
        if (!found) {
          await interaction.editReply("This doesn't look like an open mod mail ticket thread.");
          return;
        }
        const config = getConfig(interaction.guildId);
        const allowed = authorizedIds?.has(interaction.user.id) || hasModmailRole(interaction.member, config?.roleId);
        if (!allowed) {
          await interaction.editReply("You don't have the mod mail role required to close tickets.");
          return;
        }
        closeTicket(found.userId);
        await interaction.editReply('✅ Ticket closed.');
        await interaction.channel.send('🔒 This ticket has been closed by staff.').catch(() => {});
        await interaction.channel.setArchived(true).catch(() => {});
        const user = await client.users.fetch(found.userId).catch(() => null);
        if (user) {
          await user
            .send('🔒 Your mod mail ticket has been closed by staff. Send another message anytime to open a new one.')
            .catch(() => {});
        }
        return;
      }
    } catch (err) {
      console.error(`[modmail] Error handling /${interaction.commandName}:`, err.message);
      const msg = '⚠️ Something went wrong with that mod mail command.';
      try {
        if (interaction.deferred || interaction.replied) await interaction.editReply(msg);
        else await interaction.reply({ content: msg, flags: MessageFlags.Ephemeral });
      } catch {
        // interaction token expired - nothing more we can do
      }
    }
  });

  // ---- Message relaying ----
  client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    try {
      // DM from a user -> relay into (or open) their ticket thread
      if (!message.guild) {
        const guildId = await resolveGuildForUser(client, message.author.id);
        if (!guildId) return; // mod mail isn't set up anywhere the bot shares with this user
        const thread = await getOrCreateThread(client, guildId, message.author.id, message.author.tag);
        if (!thread) return;
        await thread.send({
          embeds: [
            new EmbedBuilder()
              .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL() })
              .setDescription(message.content || '*[no text content]*')
              .setColor(0x2ecc71)
              .setTimestamp(),
          ],
        });
        await message.react('✅').catch(() => {});
        return;
      }

      // A message inside an open ticket thread -> relay to the user, but ONLY from someone with the configured role
      if (message.channel.isThread()) {
        const found = findTicketByThread(message.channel.id);
        if (!found || found.ticket.status !== 'open') return;

        const config = getConfig(message.guild.id);
        if (!hasModmailRole(message.member, config?.roleId) && !authorizedIds?.has(message.author.id)) {
          return; // silently ignore - not authorized mod mail staff
        }

        const user = await client.users.fetch(found.userId).catch(() => null);
        if (!user) return;
        await user
          .send({
            embeds: [
              new EmbedBuilder()
                .setAuthor({ name: `${message.author.tag} (Staff)`, iconURL: message.author.displayAvatarURL() })
                .setDescription(message.content || '*[no text content]*')
                .setColor(0xe67e22)
                .setTimestamp(),
            ],
          })
          .catch(async () => {
            await message.reply("⚠️ Couldn't deliver — this user has DMs disabled.").catch(() => {});
          });
        await message.react('📨').catch(() => {});
      }
    } catch (err) {
      console.error('[modmail] Error relaying message:', err.message);
    }
  });
}

const commands = [
  new SlashCommandBuilder()
    .setName('modmail')
    .setDescription('Send a message to server staff privately.')
    .addStringOption((o) => o.setName('message').setDescription('Your message to staff.').setRequired(true)),

  new SlashCommandBuilder()
    .setName('setmodmailchannel')
    .setDescription('Set which channel mod mail ticket threads get created under. (Staff only)')
    .addChannelOption((o) =>
      o
        .setName('channel')
        .setDescription('Parent channel for ticket threads.')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    ),

  new SlashCommandBuilder()
    .setName('setmodmailrole')
    .setDescription('Set which role can reply to mod mail tickets. (Staff only)')
    .addRoleOption((o) => o.setName('role').setDescription('The mod mail staff role.').setRequired(true)),

  new SlashCommandBuilder()
    .setName('close')
    .setDescription('Close the current mod mail ticket. Run inside the ticket thread.'),
];

module.exports = { attach, commands };
